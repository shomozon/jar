package run;

class function
{
  double y;
  double f(double x){
    return y;
  }
}