public class function
{
  double y;
  public double f(double x){
    return y;
  }
}