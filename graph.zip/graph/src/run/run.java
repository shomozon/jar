package run;

import main.graph;


class run
{
  public static void main(String[] args)
  {

    function f = new function();
    double[] x = new double[301];
    int[] y = new int[301];
    StringBuilder sb = new StringBuilder();

    for (int i = -150; i <= 150; i++){
      x[i+150] = i / (10.0);
      y[i+150] = Math.round((float)(f.f(x[i+150])*10));
      if (y[i+150] <= 100 && y[i+150] >= -100){
        sb.append(Integer.toString(y[i+150]) + "\n");
      } else {
        sb.append("null" + "\n");
      }
    }

    graph.filewrite("src/Logtxt/log.txt", sb.toString(), false);

  }
}
