package run;

import javax.tools.StandardJavaFileManager;
import javax.tools.JavaFileObject;
import java.io.*;
import java.nio.file.*;
import java.util.List;
import main.graph;


class run
{
  public static void main(String[] args)
  {

    function f = new function();
    double[] x = new double[201];
    int[] y = new int[201];
    StringBuilder sb = new StringBuilder();

    for (int i = -100; i <= 100; i++){
      x[i+100] = i / (10.0);
      y[i+100] = Math.round((float)(f.f(x[i+100])*10));
      if (y[i+100] <= 100 && y[i+100] >= -100){
        sb.append(Integer.toString(y[i+100]) + "\n");
      } else {
        sb.append("null" + "\n");
      }
    }

    graph.filewrite("src/Logtxt/log.txt", sb.toString(), false);

  }
}
