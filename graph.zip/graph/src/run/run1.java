package run;

import javax.tools.StandardJavaFileManager;
import javax.tools.JavaFileObject;
import java.io.*;
import java.nio.file.*;
import java.util.List;
import main.graph;


class run1
{
  public static void main(String[] args)
  {

    double a = Double.parseDouble(graph.readfile("src/Logtxt/log_v.txt").get(0));

    function f = new function();
    double[] x = new double[841];
    int[] y = new int[841];
    int[] dy = new int[841];
    StringBuilder sb = new StringBuilder();

    for (int i = -420; i <= 420; i++){
      x[i+420] = i / (10.0 * a);
      y[i+420] = Math.round((float)(f.f(x[i+420])*10*a));

      if (y[i+420] <= 270 && y[i+420] >= -270) {

        if (i>=-419) {
          if (y[i+419] <= 270 && y[i+419] >= -270) {

            dy[i+420] = Math.abs(y[i+419]-y[i+420]);

            if (dy[i+420] != 1) {
              sb.append(Integer.toString(dy[i+420]/2) + "\n");
              sb.append(Integer.toString(dy[i+420]-dy[i+420]/2) + "\n");
            } else {
              sb.append("0\n0\n");
            }
          } else {
            sb.append("null" + "\n" + "null" + "\n");
          }

          sb.append(Integer.toString(y[i+420]) + "\n");
        } else {
          sb.insert(0, "null\n");
          sb.insert(5, "null\n");
          sb.insert(10, Integer.toString(y[0]) + "\n");
        }
      } else {
        sb.append("null" + "\n" + "null" + "\n" + "null" + "\n");
      }
    }

    graph.filewrite("src/Logtxt/log1.txt", sb.toString(), false);

  }
}
