package run;

class function
{
  double y;
  double f(double x){
    // 以下に関数を入力 (x:入力, y:出力) *java //
    y = x*x;
    return y;
  }
}