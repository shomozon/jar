import javax.tools.StandardJavaFileManager;
import javax.tools.JavaFileObject;
import java.io.*;
import java.nio.file.*;
import java.util.List;


class note
{
  public static void main(String[] args)
  {
    List<String> list = graph.readfile("");
    System.out.print(list.size());
  }
}