package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.tools.ToolProvider;
import javax.tools.JavaCompiler;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;



class ShiftEnterAction
{
  TextArea textarea;
  JTextArea logtext;
  canvas can;
  JLabel labelF;

  void Conduct()
  {
    textarea.text = textarea.getText().split("\\R");

    StringBuilder sb = new StringBuilder();
    StringBuilder sbl = new StringBuilder();

    sb.append("package run;\n\nclass function\n{\n  double y;\n  double f(double x){\n");

    for (String text : textarea.text) {
      sb.append("    " + text + "\n");
      if (!text.equals("// 以下に関数を入力 (x:入力, y:出力) *java //")) {
        sbl.append(text + "<br>");
      }
    }

    sb.append("    return y;\n  }\n}");

    graph.filewrite("src/run/function.java", sb.toString(), false);

    JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
    int result = compiler.run(null, null, null, "src/run/function.java");

    if (result != 0) {
      logtext.append("\n" + "error");
      textarea.backuptext = new ArrayList<>(Arrays.asList(textarea.getText().split("\\R")));
      return;
    }

    textarea.backuptext = new ArrayList<>(Arrays.asList(textarea.getText().split("\\R")));

    logtext.append("\n" + "Done");

    graph.Pb("run.run");

    can.repaint();

    graph.filewrite("src/Logtxt/log_v.txt", "1.0", false);

    labelF.setText("<html>" + sbl.toString() + "</html>");

  }
}

class viewpanelAction
{
  void Conduct()
  {
    JFrame jf1 = new JFrame();
    jf1.setSize(900, 680);
    jf1.setLayout(null);

    AtomicBoolean b1 = new AtomicBoolean();

    ViewPanel p = new ViewPanel();
    p.b1 = b1;

    p.setLayout(null);
    p.setBounds(0, 0, 900, 650);

    JButton button1 = new JButton("png保存");
    button1.setBounds(400, 600, 60, 35);

    JButton button2 = new JButton("拡大(×2)");
    button2.setBounds(110, 600, 80, 35);

    JButton button3 = new JButton("拡大(×1/2)");
    button3.setBounds(210, 600, 80, 35);

    JButton button4 = new JButton("戻る");
    button4.setBounds(30, 600, 60, 35);

    JButton button5 = new JButton("drawline_c");
    button5.setBounds(310, 600, 80, 35);

    p.add(button1);
    p.add(button2);
    p.add(button3);
    p.add(button4);
    p.add(button5);
    jf1.add(p);
    jf1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    jf1.setVisible(true);


    button1.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        PngIMGCreation pngcreation = new PngIMGCreation(p);
      }
    });

    button2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Double a = Double.parseDouble(graph.readfile("src/Logtxt/log_v.txt").get(0));
        graph.filewrite("src/Logtxt/log_v.txt", Double.toString(a * 2), false);
        p.repaint();
      }
    });

    button3.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Double a = Double.parseDouble(graph.readfile("src/Logtxt/log_v.txt").get(0));
        graph.filewrite("src/Logtxt/log_v.txt", Double.toString(a * 0.5), false);
        p.repaint();
      }
    });

    button4.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jf1.dispose();
      }
    });

    button5.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        b1.set(!b1.get());
        if (b1.get()) {
          button5.setText("dot");
        } else {
          button5.setText("drawline");
        }
        p.repaint();
      }
    });
  }
}
