package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.io.*;
import javax.tools.ToolProvider;
import javax.tools.StandardJavaFileManager;
import javax.tools.JavaFileObject;
import java.nio.file.*;
import java.util.List;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.ArrayList;
import java.util.Arrays;


class ViewPanel extends JPanel
{
  AtomicBoolean b1;

  @Override
  public void paintComponent(Graphics g) {

    super.paintComponent(g);

    String a = graph.readfile("src/Logtxt/log_v.txt").get(0);

    Graphics2D g2 = (Graphics2D) g;
    AffineTransform old = g2.getTransform();
    g2.transform(AffineTransform.getTranslateInstance(450, 300));
    g2.transform(AffineTransform.getScaleInstance(1, -1));
    g2.drawLine(-430, -280, 430, -280);
    g2.drawLine(430, 280, -430, 280);
    g2.drawLine(-430, -280, -430, 280);
    g2.drawLine(430, -280, 430, 280);
    g2.drawLine(0, -270, 0, 270);
    g2.drawLine(420, 0, -420, 0);
    g2.drawString("O", -12, -3);


    graph.Pb("run.run1");

    List<String> list = graph.readfile("src/Logtxt/log1.txt");

    if (!b1.get()) {
      for (int i = -420; i <= 420; i++){
        if (!(list.get((i+421)*3-1).equals("null"))) {
          g2.fillRect(i, Integer.parseInt(list.get((i+421)*3-1)), 1, 1);
        }
      }
    } else {
      for (int i = -420; i <= 420; i++){
        if (!(list.get((i+421)*3-1).equals("null"))) {
          g2.fillRect(i, Integer.parseInt(list.get((i+421)*3-1)), 1, 1);
        }
        if (i >= -419 && i <= 419 && !(list.get((i+421)*3-1).equals("null")) && !(list.get((i+420)*3-1).equals("null")) && !(list.get((i+422)*3-1).equals("null"))) {
          g2.drawLine(i, Integer.parseInt(list.get((i+421)*3-1)) - Integer.parseInt(list.get((i+421)*3-2)), i, Integer.parseInt(list.get((i+421)*3-1)) + Integer.parseInt(list.get((i+422)*3-3)));
        }
      }
    }
    g2.setTransform(old);
    g2.drawString("Scope(10) × " + a, 480, 620);
  }

}


class canvas extends JPanel
{
  @Override
  public void paintComponent(Graphics g)
  {
    super.paintComponent(g);

    Graphics2D g2 = (Graphics2D) g;
    AffineTransform old = g2.getTransform();
    g2.transform(AffineTransform.getTranslateInstance(170, 120));
    g2.transform(AffineTransform.getScaleInstance(1, -1));
    g2.drawLine(-160, 110, 160, 110);
    g2.drawLine(-160, -110, 160, -110);
    g2.drawLine(-160, -110, -160, 110);
    g2.drawLine(160, -110, 160, 110);
    g2.drawLine(0, -100, 0, 100);
    g2.drawLine(-150, 0, 150, 0);
    g2.drawString("O", -12, -3);

    graph.Pb("run.run");

    List<String> list = graph.readfile("src/Logtxt/log.txt");

    for (int i = -100; i <= 100; i++){
      if (!(list.get(i+100).equals("null"))) {
        g2.fillRect(i, Integer.parseInt(list.get(i+100)), 1, 1);
      }
    }

  }
}
