package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


class GraphPanel
{
  JPanel panel;
  TextArea textarea;
  JTextArea logtext;
  String sbltext;
  canvas can;
  JButton button;

  GraphPanel()
  {
    panel = new JPanel();
    panel.setLayout(null);
    panel.setBounds(0, 0, 900, 500);

    can = new canvas();
    can.setBounds(0, 0, 340, 240);

    textarea = new TextArea();
    JScrollPane scrollPane1 = new JScrollPane(textarea);
    scrollPane1.setBounds(350, 10, 300, 400);

    logtext = new JTextArea();
    logtext.setText("// ログ表示");
    logtext.setEditable(false);

    JScrollPane scrollPane = new JScrollPane(logtext);
    scrollPane.setBounds(660, 310, 200, 100);

    button = new JButton("View");
    button.setBounds(20, 240, 60, 35);

    JLabel label = new JLabel("graph-tab");
    label.setBounds(825, 5, 80, 20);


    textarea.backuptext = graph.readfile("src/Logtxt/note_f.txt");

    StringBuilder sb = new StringBuilder();
    StringBuilder sb1 = new StringBuilder();
    StringBuilder sbl = new StringBuilder();

    sb.append("package run;\n\n" + "class function\n{\n  double y;\n  double f(double x){\n");

    for (String t : textarea.backuptext) {
      sb.append("    " + t + "\n");
      sb1.append(t + "\n");
      if (!t.equals("// 以下に関数を入力 (x:入力, y:出力) *java //")) {
        sbl.append(t + "<br>");
      }
    }

    sbltext = sbl.toString();

    sb.append("    return y;\n  }\n}");

    graph.filewrite("src/run/function.java", sb.toString(), false);

    textarea.setText(sb1.toString());


    panel.add(can);
    panel.add(scrollPane);
    panel.add(scrollPane1);
    panel.add(button);
    panel.add(label);
  }
}

class CalculationPanel
{
  JPanel panel1;
  JLabel labelF;

  CalculationPanel(String sbltext)
  {
    panel1 = new JPanel() {
      @Override
      public void paintComponent(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(10,40, 300, 300);
        g.setColor(Color.BLACK);
        g.drawLine(10, 40, 10, 340);
        g.drawLine(10, 340, 310, 340);
        g.drawLine(310, 40, 310, 340);
        g.drawLine(310, 40, 10, 40);
      }
    };

    panel1.setLayout(null);
    panel1.setBounds(0, 0, 900, 500);

    JLabel label1 = new JLabel("calculate-tab");
    label1.setBounds(805, 5, 90, 20);

    JLabel label2 = new JLabel("x(入力) -> y(出力)");
    label2.setBounds(10, 10, 150, 20);

    JLabel labelx = new JLabel("x");
    labelx.setBounds(350, 40, 10, 10);

    labelF = new JLabel("<html>" + sbltext + "</html>");
    labelF.setVerticalAlignment(SwingConstants.TOP);
    labelF.setBounds(15, 45, 250, 250);

    panel1.add(label1);
    panel1.add(label2);
    panel1.add(labelF);

    JTextField InputText = new JTextField();

  }
}
