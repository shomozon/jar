package main.Action;

import java.awt.event.*;
import javax.swing.*;
import main.CalculationPanelConduction;
import main.GraphPanelConduction;


public class GraphActionMap {
	
	public GraphActionMap() {

		InputMap im_t = GraphPanelConduction.textarea.getInputMap(JComponent.WHEN_FOCUSED);
		ActionMap am_t = GraphPanelConduction.textarea.getActionMap();
		InputMap im_wp = GraphPanelConduction.cardPanel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
		ActionMap am_wp = GraphPanelConduction.cardPanel.getActionMap();

		im_t.put(KeyStroke.getKeyStroke("shift ENTER"), "ShiftEnter");
		am_t.put("ShiftEnter", new AbstractAction() {
			public void actionPerformed(ActionEvent e) {

				ShiftEnterAction action = new ShiftEnterAction();

				action.Conduct();

			}
		});

		im_wp.put(KeyStroke.getKeyStroke("LEFT"), "leftkey");
		am_wp.put("leftkey", new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				GraphPanelConduction.cardLayout.show(GraphPanelConduction.cardPanel, "panel");
			}
		});

		im_wp.put(KeyStroke.getKeyStroke("RIGHT"), "rightkey");
		am_wp.put("rightkey", new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				GraphPanelConduction.cardLayout.show(GraphPanelConduction.cardPanel, "panel1");
			}
		});

		GraphPanelConduction.panel.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				GraphPanelConduction.cardPanel.requestFocusInWindow();
			}
		});
		CalculationPanelConduction.panel1.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				GraphPanelConduction.cardPanel.requestFocusInWindow();
			}
		});

		GraphPanelConduction.button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ViewPanelAction action = new ViewPanelAction();
				action.Conduct();

			}
		});
	}
}
