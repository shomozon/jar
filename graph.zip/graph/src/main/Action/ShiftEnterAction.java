package main.Action;

import javax.tools.ToolProvider;
import javax.tools.JavaCompiler;
import java.util.ArrayList;
import java.util.Arrays;
import main.CalculationPanelConduction;
import main.GraphPanelConduction;
import main.graph;


public class ShiftEnterAction
{
	
  String[] text;

  public void Conduct()
  {
    text = GraphPanelConduction.textarea.getText().split("\\R");

    StringBuilder sb = new StringBuilder();
    StringBuilder sbl = new StringBuilder();

    sb.append("package run;\n\nclass function\n{\n  double y;\n  double f(double x){\n");

    for (String t : text) {
      sb.append("    " + t + "\n");
      if (!t.equals("// 以下に関数を入力 (x:入力, y:出力) *java //")) {
        sbl.append(t + "<br>");
      }
    }

    sb.append("    return y;\n  }\n}");

    graph.filewrite("src/run/function.java", sb.toString(), false);

    JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
    int result = compiler.run(null, null, null, "-d", "bin", "src/run/function.java");

    if (result != 0) {
    	GraphPanelConduction.logtext.append("\n" + "error");
    	GraphPanelConduction.textarea.backuptext = new ArrayList<>(Arrays.asList(GraphPanelConduction.textarea.getText().split("\\R")));
      return;
    }

    GraphPanelConduction.textarea.backuptext = new ArrayList<>(Arrays.asList(GraphPanelConduction.textarea.getText().split("\\R")));

    GraphPanelConduction.logtext.append("\n" + "Done");

    GraphPanelConduction.can.repaint();

    graph.filewrite("src/Logtxt/log_v.txt", "1.0", false);

    CalculationPanelConduction.labelF.setText("<html>" + sbl.toString() + "</html>");

  }
}
