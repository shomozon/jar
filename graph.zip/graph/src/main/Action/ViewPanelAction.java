package main.Action;

import javax.swing.*;
import java.awt.event.*;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import main.graph;
import main.JComponent.Panel.ViewPanel;


public class ViewPanelAction {
	
	public void Conduct() {
		
		JFrame jf1 = new JFrame();
		jf1.setSize(900, 680);
		jf1.setLayout(null);

		ViewPanel p = new ViewPanel();

		p.setLayout(null);
		p.setBounds(0, 0, 900, 650);

		JButton button1 = new JButton("png保存");
		button1.setBounds(400, 600, 60, 35);

		JButton button2 = new JButton("拡大(×2)");
		button2.setBounds(110, 600, 80, 35);

		JButton button3 = new JButton("拡大(×1/2)");
		button3.setBounds(210, 600, 80, 35);

		JButton button4 = new JButton("戻る");
		button4.setBounds(30, 600, 60, 35);

		JButton button5 = new JButton("drawline_c");
		button5.setBounds(310, 600, 80, 35);

		p.add(button1);
		p.add(button2);
		p.add(button3);
		p.add(button4);
		p.add(button5);
		jf1.add(p);
		jf1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf1.setVisible(true);

		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PNGIMGCreate(p);
			}
		});

		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Double a = Double.parseDouble(graph.readfile("src/Logtxt/log_v.txt").get(0));
				graph.filewrite("src/Logtxt/log_v.txt", Double.toString(a * 2), false);
				p.repaint();
			}
		});

		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Double a = Double.parseDouble(graph.readfile("src/Logtxt/log_v.txt").get(0));
				graph.filewrite("src/Logtxt/log_v.txt", Double.toString(a * 0.5), false);
				p.repaint();
			}
		});

		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jf1.dispose();
			}
		});

		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewPanel.b1 = !ViewPanel.b1;
				if (ViewPanel.b1) {
					button5.setText("dot");
				} else {
					button5.setText("drawline");
				}
				p.repaint();
			}
		});
	}
	
	void PNGIMGCreate(JPanel p)
	{
		
		BufferedImage fullImage = new BufferedImage(p.getWidth(), p.getHeight(), BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2 = fullImage.createGraphics();
    p.paint(g2);
    g2.dispose();

    BufferedImage croppedImage = fullImage.getSubimage(0, 0, 900, 600);
    try {
      boolean b = true;
      for (int i = 0; b; i++) {
        File file = new File("src/img/gragh" + Integer.toString(i) + ".png");
        if (!file.exists()) {
          ImageIO.write(croppedImage, "png", file);
          b = false;
        }
      }
    } catch (IOException e) {
    }
	}
}
