package main.JComponent.TextArea;

import java.util.List;
import javax.swing.JTextArea;

public class TextArea extends JTextArea
{
  public String[] text;
  public List<String> backuptext;
}

