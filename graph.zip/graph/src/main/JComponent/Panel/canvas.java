package main.JComponent.Panel;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.List;
import javax.swing.JPanel;
import main.graph;


public class canvas extends JPanel
{
  @Override
  public void paintComponent(Graphics g)
  {
    super.paintComponent(g);

    Graphics2D g2 = (Graphics2D) g;
    g2.transform(AffineTransform.getTranslateInstance(170, 120));
    g2.transform(AffineTransform.getScaleInstance(1, -1));
    g2.drawLine(-160, 110, 160, 110);
    g2.drawLine(-160, -110, 160, -110);
    g2.drawLine(-160, -110, -160, 110);
    g2.drawLine(160, -110, 160, 110);
    g2.drawLine(0, -100, 0, 100);
    g2.drawLine(-150, 0, 150, 0);
    g2.drawString("O", -12, -3);

    graph.Pb("run.run");

    List<String> list = graph.readfile("src/Logtxt/log.txt");

    for (int i = -150; i <= 150; i++){
      if (!(list.get(i+150).equals("null"))) {
        g2.fillRect(i, Integer.parseInt(list.get(i+150)), 1, 1);
      }
    }

  }
}
