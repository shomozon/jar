package main;

import java.awt.CardLayout;
import javax.swing.*;
import main.JComponent.Panel.canvas;
import main.JComponent.TextArea.TextArea;


public class GraphPanelConduction
{
  public static JPanel panel;
  public static TextArea textarea;
  public static JTextArea logtext;
  public static String sbltext;
  public static canvas can;
  public static JButton button;
  public static JPanel cardPanel;
  public static CardLayout cardLayout;

  GraphPanelConduction()
  {
    panel = new JPanel();
    panel.setLayout(null);
    panel.setBounds(0, 0, 900, 500);

    can = new canvas();
    can.setBounds(0, 0, 340, 240);

    textarea = new TextArea();
    JScrollPane scrollPane1 = new JScrollPane(textarea);
    scrollPane1.setBounds(350, 10, 300, 400);

    logtext = new JTextArea();
    logtext.setText("// ログ表示");
    logtext.setEditable(false);

    JScrollPane scrollPane = new JScrollPane(logtext);
    scrollPane.setBounds(660, 310, 200, 100);

    button = new JButton("View");
    button.setBounds(20, 240, 60, 35);

    JLabel label = new JLabel("graph-tab");
    label.setBounds(825, 5, 80, 20);
    
    cardLayout = new CardLayout();
    cardPanel = new JPanel(cardLayout);
    cardPanel.setBounds(0, 0, 900, 500);
    
    cardPanel.add(panel, "panel");
    
    panel.add(can);
    panel.add(scrollPane);
    panel.add(scrollPane1);
    panel.add(button);
    panel.add(label);


    textarea.backuptext = graph.readfile("src/Logtxt/note_f.txt");

    StringBuilder sbf = new StringBuilder();
    StringBuilder sbt = new StringBuilder();
    StringBuilder sbl = new StringBuilder();

    sbf.append("package run;\n\n" + "class function\n{\n  double y;\n  double f(double x){\n");

    for (String t : textarea.backuptext) {
      sbf.append("    " + t + "\n");
      sbt.append(t + "\n");
      if (!t.equals("// 以下に関数を入力 (x:入力, y:出力) *java //")) {
        sbl.append(t + "<br>");
      }
    }

    sbltext = sbl.toString();

    sbf.append("    return y;\n  }\n}");

    graph.filewrite("src/run/function.java", sbf.toString(), false);

    textarea.setText(sbt.toString());
    
  }
}
