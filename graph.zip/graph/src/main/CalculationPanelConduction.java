package main;

import javax.swing.*;
import java.awt.*;


public class CalculationPanelConduction
{
  public static JPanel panel1;
  public static JLabel labelF;

  CalculationPanelConduction()
  {
    panel1 = new JPanel() {
      @Override
      public void paintComponent(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(10,40, 300, 300);
        g.setColor(Color.BLACK);
        g.drawLine(10, 40, 10, 340);
        g.drawLine(10, 340, 310, 340);
        g.drawLine(310, 40, 310, 340);
        g.drawLine(310, 40, 10, 40);
      }
    };

    panel1.setLayout(null);
    panel1.setBounds(0, 0, 900, 500);

    JLabel label1 = new JLabel("calculate-tab");
    label1.setBounds(805, 5, 90, 20);

    JLabel label2 = new JLabel("x(入力) -> y(出力)");
    label2.setBounds(10, 10, 150, 20);

    JLabel labelx = new JLabel("x");
    labelx.setBounds(350, 40, 10, 10);

    labelF = new JLabel("<html>" + GraphPanelConduction.sbltext + "</html>");
    labelF.setVerticalAlignment(SwingConstants.TOP);
    labelF.setBounds(15, 45, 250, 250);
    
    GraphPanelConduction.cardPanel.add(panel1, "panel1");

    panel1.add(label1);
    panel1.add(label2);
    panel1.add(labelF);

  }
}
