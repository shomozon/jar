package main;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.tools.ToolProvider;
import javax.tools.StandardJavaFileManager;
import javax.tools.JavaFileObject;
import java.nio.file.*;


class PngIMGCreation
{
  JPanel p;

  PngIMGCreation(JPanel p1) {
    p = p1;
    BufferedImage fullImage = new BufferedImage(p.getWidth(), p.getHeight(), BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2 = fullImage.createGraphics();
    p.paint(g2);
    g2.dispose();

    BufferedImage croppedImage = fullImage.getSubimage(0, 0, 900, 600);
    try {
      boolean b = true;
      for (int i = 0; b; i++) {
        File file = new File("src/img/gragh" + Integer.toString(i) + ".png");
        if (!file.exists()) {
          ImageIO.write(croppedImage, "png", file);
          b = false;
        }
      }
    } catch (IOException e) {
    }
  }
}
