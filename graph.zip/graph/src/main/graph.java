package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.io.*;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import javax.tools.StandardJavaFileManager;
import javax.tools.JavaFileObject;
import java.nio.file.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;


public class graph
{
  public static void main(String[] args)
  {
    JFrame jf = new JFrame();
    jf.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    jf.setSize(900, 500);
    jf.setLayout(null);

    CardLayout cardLayout = new CardLayout();

    JPanel cardPanel = new JPanel(cardLayout);
    cardPanel.setBounds(0, 0, 900, 500);

    GraphPanel graphpanel = new GraphPanel();

    JPanel panel = graphpanel.panel;
    TextArea textarea = graphpanel.textarea;
    JTextArea logtext = graphpanel.logtext;
    canvas can = graphpanel.can;
    JButton button = graphpanel.button;

    CalculationPanel calpanel = new CalculationPanel(graphpanel.sbltext);

    JPanel panel1 = calpanel.panel1;
    JLabel labelF = calpanel.labelF;

    cardPanel.add(panel, "panel");
    cardPanel.add(panel1, "panel1");

    jf.add(cardPanel);

    cardLayout.show(cardPanel, "panel");
    jf.setVisible(true);

    jf.addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        StringBuilder sb = new StringBuilder();
        for (String t : textarea.backuptext) {
          sb.append(t + "\n");
          graph.filewrite("src/Logtxt/note_f.txt", sb.toString(), false);
          graph.filewrite("src/run/function.java", "package run;\n\n" + "class function\n{\n  double y;\n  double f(double x){\n    return y;\n  }\n}", false);
          jf.dispose();
/*
          Window[] window = Window.getWindows();
          if (window[0].isShowing()) {
            window[0].dispose();
          }
*/
        }
      }
    });

    AtomicBoolean b2 = new AtomicBoolean();

    InputMap im_t = textarea.getInputMap(JComponent.WHEN_FOCUSED);
    ActionMap am_t = textarea.getActionMap();
    InputMap im_wp = cardPanel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
    ActionMap am_wp = cardPanel.getActionMap();

    im_t.put(KeyStroke.getKeyStroke("shift ENTER"), "ShiftEnter");
    am_t.put("ShiftEnter", new AbstractAction() {
      public void actionPerformed(ActionEvent e) {

        ShiftEnterAction action = new ShiftEnterAction();

        action.textarea = textarea;
        action.logtext = logtext;
        action.can = can;
        action.labelF = labelF;

        action.Conduct();
      }
    });

    im_wp.put(KeyStroke.getKeyStroke("LEFT"), "leftkey");
    am_wp.put("leftkey", new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
        cardLayout.show(cardPanel, "panel");
      }
    });

    im_wp.put(KeyStroke.getKeyStroke("RIGHT"), "rightkey");
    am_wp.put("rightkey", new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
        cardLayout.show(cardPanel, "panel1");
      }
    });

    panel.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        cardPanel.requestFocusInWindow();
      }
    });
    panel1.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        cardPanel.requestFocusInWindow();
      }
    });


    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {

        viewpanelAction action = new viewpanelAction();
        action.Conduct();

      }
    });
  }

  public static List<String> readfile(String n) {

    List<String> list = new ArrayList<>();
    try {
      Path path = Paths.get(n);
      list = Files.readAllLines(path);
    } catch (IOException e) {
    }
    return list;
  }

  public static void Pb(String n) {
    try {
      ProcessBuilder pb = new ProcessBuilder("java", "-cp", "bin", n);
      pb.inheritIO();
      pb.start().waitFor();
    } catch(IOException | InterruptedException er) {
    }
  }

  public static void filewrite(String n, String c, boolean b) {
    try (FileWriter writer = new FileWriter(n, b)){
      writer.write(c);
      writer.close();
    } catch (IOException e) {
    }
  }
  
}


class TextArea extends JTextArea
{
  String[] text;
  List<String> backuptext;
}
