package main;

import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.util.List;
import java.util.ArrayList;
import main.Action.GraphActionMap;


public class graph
{
  public static void main(String[] args)
  {
    JFrame jf = new JFrame();
    jf.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    jf.setSize(900, 500);
    jf.setLayout(null);

    new GraphPanelConduction();

    new CalculationPanelConduction();
    
    new GraphActionMap();

    jf.add(GraphPanelConduction.cardPanel);

    GraphPanelConduction.cardLayout.show(GraphPanelConduction.cardPanel, "panel");
    jf.setVisible(true);

    jf.addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
      	
        StringBuilder sb = new StringBuilder();
        for (String t : GraphPanelConduction.textarea.backuptext) {
          sb.append(t + "\n");
          graph.filewrite("src/Logtxt/note_f.txt", sb.toString(), false);
          graph.filewrite("src/run/function.java", "package run;\n\n" + "class function\n{\n  double y;\n  double f(double x){\n    return y;\n  }\n}", false);
          jf.dispose();
/*
          Window[] window = Window.getWindows();
          if (window[0].isShowing()) {
            window[0].dispose();
          }
*/
        }
      }
    });
  }

  public static List<String> readfile(String n) {

    List<String> list = new ArrayList<>();
    try {
      Path path = Paths.get(n);
      list = Files.readAllLines(path);
    } catch (IOException e) {
    }
    return list;
  }

  public static void Pb(String n) {
    try {
      ProcessBuilder pb = new ProcessBuilder("java", "-cp", "bin", n);
      pb.inheritIO();
      pb.start().waitFor();
    } catch(IOException | InterruptedException e) {
    }
  }

  public static void filewrite(String n, String c, boolean b) {
    try (FileWriter writer = new FileWriter(n, b)){
      writer.write(c);
      writer.close();
    } catch (IOException e) {
    }
  }
  
}


