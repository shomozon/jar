import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.io.*;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import javax.tools.StandardJavaFileManager;
import javax.tools.JavaFileObject;
import java.nio.file.*;
import java.util.List;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.ArrayList;
import java.util.Arrays;


class graph
{
  public static void main(String[] args)
  {
    JFrame jf = new JFrame();
    jf.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    jf.setSize(900, 500);
    jf.setLayout(null);

    CardLayout cardLayout = new CardLayout();

    JPanel cardPanel = new JPanel(cardLayout);
    cardPanel.setBounds(0, 0, 900, 500);
    //cardPanel.setFocusable(true);
    //cardPanel.requestFocusInWindow();

    JPanel panel = new JPanel();
    panel.setLayout(null);
    panel.setBounds(0, 0, 900, 500);

    JPanel panel1 = new JPanel() {
      @Override
      public void paintComponent(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(10,40, 300, 300);
        g.setColor(Color.BLACK);
        g.drawLine(10, 40, 10, 340);
        g.drawLine(10, 340, 310, 340);
        g.drawLine(310, 40, 310, 340);
        g.drawLine(310, 40, 10, 40);
      }
    };

    panel1.setLayout(null);
    panel1.setBounds(0, 0, 900, 500);

    canvas can = new canvas();
    can.setBounds(0, 0, 340, 240);

    TextArea textarea = new TextArea();
    JScrollPane scrollPane1 = new JScrollPane(textarea);
    scrollPane1.setBounds(350, 10, 300, 400);

    textarea.backuptext = graph.readfile("note_f.txt");

    StringBuilder sb = new StringBuilder();
    StringBuilder sb1 = new StringBuilder();
    StringBuilder sbl = new StringBuilder();

    sb.append("public class function\n{\n  double y;\n  public double f(double x){\n");

    for (String t : textarea.backuptext) {
      sb.append("    " + t + "\n");
      sb1.append(t + "\n");
      if (!t.equals("// 以下に関数を入力 (x:入力, y:出力) *java //")) {
        sbl.append(t + "<br>");
      }
    }

    sb.append("    return y;\n  }\n}");

    graph.filewrite("function.java", sb.toString(), false);

    textarea.setText(sb1.toString());

    TextArea logtext = new TextArea();
    logtext.setText("// ログ表示");
    logtext.setEditable(false);

    JScrollPane scrollPane = new JScrollPane(logtext);
    scrollPane.setBounds(660, 310, 200, 100);

    JButton button = new JButton("View");
    button.setBounds(20, 240, 60, 35);

    JLabel label = new JLabel("graph-tab");
    label.setBounds(825, 5, 80, 20);

    panel.add(can);
    panel.add(scrollPane);
    panel.add(scrollPane1);
    panel.add(button);
    panel.add(label);

    JLabel label1 = new JLabel("calculate-tab");
    label1.setBounds(805, 5, 90, 20);

    JLabel label2 = new JLabel("x(入力) -> y(出力)");
    label2.setBounds(10, 10, 150, 20);

    JLabel labelF = new JLabel("<html>" + sbl.toString() + "</html>");
    labelF.setVerticalAlignment(SwingConstants.TOP);
    labelF.setBounds(15, 45, 250, 250);

    JLabel labelx = new JLabel("x");
    labelx.setBounds(350, 40, 10, 10);

    JTextField InputText = new JTextField();
    
    panel1.add(label1);
    panel1.add(label2);
    panel1.add(labelF);
    panel1

    cardPanel.add(panel, "panel");
    cardPanel.add(panel1, "panel1");

    jf.add(cardPanel);

    cardLayout.show(cardPanel, "panel");
    jf.setVisible(true);

    jf.addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        StringBuilder sb = new StringBuilder();
        for (String t : textarea.backuptext) {
          sb.append(t + "\n");
          graph.filewrite("note_f.txt", sb.toString(), false);
          graph.filewrite("function.java", "public class function\n{\n  double y;\n  public double f(double x){\n    return y;\n  }\n}", false);
          jf.dispose();
/*
          Window[] window = Window.getWindows();
          if (window[0].isShowing()) {
            window[0].dispose();
          }
*/
        }
      }
    });

    AtomicBoolean b2 = new AtomicBoolean();

    InputMap im_t = textarea.getInputMap(JComponent.WHEN_FOCUSED);
    ActionMap am_t = textarea.getActionMap();
    InputMap im_wp = cardPanel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
    ActionMap am_wp = cardPanel.getActionMap();

    im_t.put(KeyStroke.getKeyStroke("shift ENTER"), "ShiftEnter");
    am_t.put("ShiftEnter", new AbstractAction() {
      public void actionPerformed(ActionEvent e) {

        textarea.text = textarea.getText().split("\\R");

        StringBuilder sb = new StringBuilder();
        StringBuilder sbl = new StringBuilder();

        sb.append("public class function\n{\n  double y;\n  public double f(double x){\n");

        for (String text : textarea.text) {
          sb.append("    " + text + "\n");
          if (!text.equals("// 以下に関数を入力 (x:入力, y:出力) *java //")) {
            sbl.append(text + "<br>");
          }
        }

        sb.append("    return y;\n  }\n}");

        graph.filewrite("function.java", sb.toString(), false);

        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        int result = compiler.run(null, null, null, "function.java");

        if (result != 0) {
          logtext.append("\n" + "error");
          textarea.backuptext = new ArrayList<>(Arrays.asList(textarea.getText().split("\\R")));
          return;
        }

        textarea.backuptext = new ArrayList<>(Arrays.asList(textarea.getText().split("\\R")));

        logtext.append("\n" + "Done");

        graph.Pb("run");

        can.repaint();

        graph.filewrite("log_v.txt", "1.0", false);

        labelF.setText("<html>" + sbl.toString() + "</html>");

      }
    });

    im_wp.put(KeyStroke.getKeyStroke("LEFT"), "leftkey");
    am_wp.put("leftkey", new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
        cardLayout.show(cardPanel, "panel");
      }
    });

    im_wp.put(KeyStroke.getKeyStroke("RIGHT"), "rightkey");
    am_wp.put("rightkey", new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
        cardLayout.show(cardPanel, "panel1");
      }
    });

    panel.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        cardPanel.requestFocusInWindow();
      }
    });
    panel1.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        cardPanel.requestFocusInWindow();
      }
    });


    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        JFrame jf1 = new JFrame();
        jf1.setSize(900, 680);
        jf1.setLayout(null);

        AtomicBoolean b1 = new AtomicBoolean();

        ViewPanel p = new ViewPanel();
        p.b1 = b1;

        p.setLayout(null);
        p.setBounds(0, 0, 900, 650);

        JButton button1 = new JButton("png保存");
        button1.setBounds(400, 600, 60, 35);

        JButton button2 = new JButton("拡大(×2)");
        button2.setBounds(110, 600, 80, 35);

        JButton button3 = new JButton("拡大(×1/2)");
        button3.setBounds(210, 600, 80, 35);

        JButton button4 = new JButton("戻る");
        button4.setBounds(30, 600, 60, 35);

        JButton button5 = new JButton("drawline_c");
        button5.setBounds(310, 600, 80, 35);

        p.add(button1);
        p.add(button2);
        p.add(button3);
        p.add(button4);
        p.add(button5);
        jf1.add(p);
        jf1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf1.setVisible(true);

        ActionListener pngcreation = new PngIMGCreation(p);
        button1.addActionListener(pngcreation);

        button2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Double a = Double.parseDouble(readfile("log_v.txt").get(0));
            graph.filewrite("log_v.txt", Double.toString(a * 2), false);
            p.repaint();
          }
        });

        button3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Double a = Double.parseDouble(readfile("log_v.txt").get(0));
            graph.filewrite("log_v.txt", Double.toString(a * 0.5), false);
            p.repaint();
          }
        });

        button4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jf1.dispose();
          }
        });

        button5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            b1.set(!b1.get());
            if (b1.get()) {
              button5.setText("dot");
            } else {
              button5.setText("drawline");
            }
            p.repaint();
          }
        });
      }
    });
  }

  static List<String> readfile(String n) {

    List<String> list = new ArrayList<>();
    try {
      Path path = Paths.get(n);
      list = Files.readAllLines(path);
    } catch (IOException e) {
    }
    return list;
  }

  static void Pb(String n) {
    try {
      ProcessBuilder pb = new ProcessBuilder("java", "-cp", ".", n);
      pb.inheritIO();
      pb.start().waitFor();
    } catch(IOException | InterruptedException er) {
    }
  }

  static void filewrite(String n, String c, boolean b) {
    try (FileWriter writer = new FileWriter(n, b)){
      writer.write(c);
      writer.close();
    } catch (IOException e) {
    }
  }

}


class TextArea extends JTextArea
{
  String[] text;
  List<String> backuptext;
}
